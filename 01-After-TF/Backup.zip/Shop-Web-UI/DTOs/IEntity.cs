﻿namespace Shop_Web_UI.DTOs
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}
