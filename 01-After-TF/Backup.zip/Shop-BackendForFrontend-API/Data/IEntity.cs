﻿namespace Shop_BackendForFrontend_API.Data
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}
