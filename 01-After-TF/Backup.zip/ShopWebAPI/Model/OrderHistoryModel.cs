namespace ShopWebAPI.Model
{
    public class OrderHistoryModel
    {
        public int Id { get; set; }
        public int OrderId { get; set; }
        public DateTime OrderDate { get; set; }

    }
}